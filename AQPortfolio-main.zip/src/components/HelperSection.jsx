import React from "react";

const HelperSection = () => {
  return <div className="h-[100vh]"></div>;
};

export default HelperSection;
